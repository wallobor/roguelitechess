extends Area2D

@export var variant = 'pawn'
@export var color = 'white'
@export var available_variant = [
	'pawn',
	'rook',
	'knight',
	'bishop',
	'queen',
	'king',
]
@export var picked = false
@export var health = 0
@export var damage = 0
@export var didOpening = false
@onready var health_label = $scaler/health_label

@onready var variant_data = {
	'pawn' : {
		'texture' : preload("res://assets/pieces/pawn.png"),
		'health' : 5,
		'damage' : 2,
		'move' : preload('res://pawn_moves.tscn'),
	} ,
	'rook' : {
		'texture' : preload("res://assets/pieces/rook.png"),
		'health' : 8,
		'damage' : 2,
		'move' : preload('res://rook_moves.tscn'),
	} ,
	'knight' : {
		'texture' : preload("res://assets/pieces/knight.png"),
		'health' : 6,
		'damage' : 3,
		'move' : preload('res://knight_moves.tscn'),
	} ,
	'bishop' : {
		'texture' : preload("res://assets/pieces/bishop.png"),
		'health' : 7,
		'damage' : 2,
		'move' : preload('res://bishop_moves.tscn'),
	} ,
	'queen' : {
		'texture' : preload("res://assets/pieces/queen.png"),
		'health' : 7,
		'damage' : 3,
		'move' : preload('res://queen_moves.tscn'),
	} ,
	'king' : {
		'texture' : preload("res://assets/pieces/king.png"),
		'health' : 12,
		'damage' : 4,
		'move' : preload('res://king_moves.tscn'),
	} ,
}

@export var pieceMove = null

var prevent = false
@export var grandparent = null
var anchor
var modifier

var started = true
var white_checked = false
var black_checked = false

var pickNoSpam = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$texture.texture = variant_data[variant].texture
	
	pieceMove = variant_data[variant]['move'].instantiate()
	add_child(pieceMove)
	
	damage = variant_data[variant]['damage']
	#setColor(color)
	
	grandparent = searchParent(self, "board", true)
	
	setColor(color)
	if color == 'black':
		anchor = searchParent(self, 'anchor_black', true)
	else:
		anchor = searchParent(self, 'anchor_white', true)
	
	#print_debug(anchor)
	appendScriptToMoveButton(self)
	updateHealth(variant_data[variant]['health'], 'set')


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#$debug_label.text = str(global_position)
	pass


func setColor(c):
	color = c
		
	if c == 'black' || c == 'b':
		$texture.material = load("res://inverse_shader.tres")
		#$depth_debug.material = load("res://inverse_shader.tres")
		pieceMove.rotate(deg_to_rad(180))
		#get_node('debug_label').set_rotation_degrees(180)
		#get_node('texture').rotate(deg_to_rad(180))
		modifier = 32
	elif c == 'white' || c == 'w':
		$texture.material = null
		#$depth_debug.material = null
		modifier = 32


func _on_pick_pressed() -> void:
	if !pickNoSpam:
		pickNoSpam = true
		var treeLists = getAllTreeNodes(pieceMove)
		#print_debug(getAllTreeNodes(variant_data[variant]['move']))
		for each in treeLists:
			if each is Area2D:
				each.visible = true
				#print_debug(treeLists)
				#print_debug(each , ' ' , each.position)
		
		for each in get_node("..").get_children():
			if each.name.contains('piece') and each != self:
				if each.picked:
					each.picked = false
					for ea in each.get_children():
						if ea.name.contains('moves'):
							ea.visible = false
		
		picked = !picked
		
		if picked:
			$sfx_click.pitch_scale = randf_range(1, 1.5)
			$sfx_click.play()
			grandparent.get_node('piece_info_icon').texture = variant_data[variant]['texture']
			grandparent.setInfoText(
				'[ Information ]
				Name: '+  str(variant)+ '
				Color: '+ str(color)+ '

				[ Stats ]
				Health: '+ str(health)+ '
				Damage: '+ str(damage)
			)
			
			grandparent.get_node('selector').visible = true
			grandparent.get_node('selector').global_position = global_position
			
			if color == 'black': grandparent.get_node('piece_info_icon').material = load("res://inverse_shader.tres")
			if color == 'white': grandparent.get_node('piece_info_icon').material = null
			z_index = grandparent.depth_index
			anchor.z_index += 10
			grandparent.depth_index += 1
			
			pieceMove.visible = true
			#print_debug(variant_data[variant]['move'])
			var parent_texture = grandparent.get_node("texture") # The board texture
			
			for each in treeLists:
				if each is Area2D:
					each.get_child(0)._ready()
					#each.theme = load("res://move_buttons.tres")
					
					var topleft_board_pos = Vector2(
						parent_texture.global_position.x - parent_texture.texture.get_width()/2,
						parent_texture.global_position.y - parent_texture.texture.get_height()/2
					)
					
					var BOARD = {
						'WIDTH' : {
							'LEFT' : parent_texture.global_position.x - parent_texture.texture.get_width()/2,
							'CENTER' : parent_texture.global_position.x,
							'RIGHT' : parent_texture.global_position.x + parent_texture.texture.get_width()/2
						},
						'HEIGHT' : {
							'TOP' : parent_texture.global_position.y - parent_texture.texture.get_height()/2,
							'CENTER' : parent_texture.global_position.y,
							'BOTTOM' : parent_texture.global_position.y + parent_texture.texture.get_height()/2
						},
					}
					
					#get_node("../ColorRect").global_position = Vector2(BOARD.WIDTH.RIGHT, BOARD.HEIGHT.BOTTOM)
					#print(get_node("../ColorRect").global_position)
					
					if !(
						(BOARD.WIDTH.LEFT < each.global_position.x and each.global_position.x < BOARD.WIDTH.RIGHT) and 
						(BOARD.HEIGHT.TOP < each.global_position.y and each.global_position.y < BOARD.HEIGHT.BOTTOM)
					):
						if each.visible == true: each.visible = false
						pass
					#
					#for otherPiece in searchParent(self, 'anchor', true).get_children():
						##print_debug(each, ' ', each.visible)
							##print_debug(round(each.global_position + each.pivot_offset))
						#if otherPiece.get_name().contains('piece'):
							##print_debug(otherPiece , ' ' , otherPiece.get_overlapping_areas())
							##print_debug(each in otherPiece.get_overlapping_areas())
							#if (otherPiece in each.get_overlapping_areas()) == true:
								##each.visible = false
								#pass
		else:
			grandparent.get_node('piece_info_icon').texture = null
			grandparent.setInfoText('')
			grandparent.get_node('selector').visible = false
			z_index = grandparent.depth_index
			anchor.z_index -= 10
			grandparent.depth_index -= 1
			
			$texture.texture = variant_data[variant].texture
			pieceMove.visible = false
			for each in treeLists:
				if each is Area2D and each.visible == true: each.visible = false
	pickNoSpam = false


func searchParent(node, targetMatch, searchByName = false, matchWholeWord = false):
	if (node.get_parent() == null): return 'searchParent() err: no matching target'
	if (node == null): return 'searchParent() err: node is null'
	if (targetMatch == null): return 'searchParent() err: target to match is null'
	
	match (searchByName):
		false:
			if (node.get_parent() == targetMatch): 
				#print('searchParent() found by node')
				return node.get_parent()
			return searchParent(node.get_parent(), targetMatch, searchByName)
		true:
			if matchWholeWord:
				if (node.get_parent().get_name() == targetMatch): 
					#print('searchParent() found by name')
					return node.get_parent()
			else:
				if (node.get_parent().get_name().contains(targetMatch)): 
					#print('searchParent() found by name')
					return node.get_parent()
			return searchParent(node.get_parent(), targetMatch, searchByName)
			
func searchChild(node, targetMatch, searchByName = false):
	if (node.get_children() == null): return 'searchChild() err: no matching target'
	if (node == null): return 'searchChild() err: node is null'
	if (targetMatch == null): return 'searchChild() err: target to match is null'
	
	match (searchByName):
		false:
			for e in node.get_children():
				if (e == targetMatch):
					return e
				return searchChild(e, targetMatch, searchByName)
		true:
			for e in node.get_children():
				if (e.get_name() == targetMatch):
					return e
				return searchChild(e, targetMatch, searchByName)


func appendScriptToMoveButton(node):
	if node.get_children():
		for each in node.get_children():
			if each.get_name() == 'move':
				each.set_script(load("res://move.gd"))
				#print_debug(each.get_path())
			elif each.get_children():
				for ea in each.get_children():
					appendScriptToMoveButton(ea)

func getAllTreeNodes(node, listOfAllNodesInTree = []):
	listOfAllNodesInTree.append(node)
	for childNode in node.get_children():
		getAllTreeNodes(childNode, listOfAllNodesInTree)
	return listOfAllNodesInTree


func updateHealth(amount, type = 'add'):
	match (type):
		'add':
			health += amount
		'set':
			health = amount
			
	var s = []; for x in range(health): s.append('▮')
	health_label.text = str(''.join(s))
	
	if health <= 0:
		if variant == 'king': grandparent.setWin('white' if color == 'black' else 'black')
		queue_free()


func hitSeizure():
	var positionNow = position
	position = Vector2(positionNow.x + 5, positionNow.y + 2)
	await get_tree().create_timer(0.05).timeout
	position = Vector2(positionNow.x -5, positionNow.y - 2)
	await get_tree().create_timer(0.05).timeout
	position = Vector2(positionNow.x + 3, positionNow.y + 5)
	await get_tree().create_timer(0.05).timeout
	position = Vector2(positionNow.x - 7, positionNow.y + 1)
	await get_tree().create_timer(0.05).timeout
	position = positionNow
	positionNow = null


func _on_mouse_entered() -> void:
	#$sfx_hover.play()
	#print_debug('Mouse Enter.')
	pass # Replace with function body.


func _on_pick_mouse_entered() -> void:
	$sfx_hover.play()
	#print_debug('Mouse Enter.')
	pass # Replace with function body.
