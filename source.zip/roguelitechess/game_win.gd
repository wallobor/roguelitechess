extends Node2D

var STARTED = false
var animTextNow = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	z_index = 210
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if STARTED:
		if $texture_vignette.modulate.a < 1: $texture_vignette.modulate.a += 0.5 * delta
		if animTextNow == true and $texture_text.modulate.a < 1: $texture_text.modulate.a += 0.75 * delta
	pass


func READYONIT():
	STARTED = true
	visible = true
	$texture_text.modulate.a = 0
	$texture_vignette.modulate.a = 0
	
	$win_theme_1.play()
	
	await get_tree().create_timer(1).timeout
	
	animTextNow = true
	$win_theme_2.play()
