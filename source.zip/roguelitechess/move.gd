extends Button

@onready var hitParticle = preload("res://hit_particle.tscn")
@onready var promoteParticle = preload("res://promote_particle.tscn")

var piece
@export var eat_mode = false
@export var eat_to = null

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	eat_mode = false
	self_modulate = Color(0, 1, 0)
	piece = searchParent(self, 'piece', true, false)
	
	if !is_connected("button_down", _on_button_down): self.button_down.connect(_on_button_down)
	for each in get_parent().get_overlapping_areas():
		if each.get_name().contains('piece') and get_parent().visible == true:
			#print_debug(each.get_name())
			if each.color == piece.color:
				get_parent().visible = false
			else:
				self_modulate = Color(1, 0, 0)
				eat_mode = true
				eat_to = each
				
				var nextMoveChild = searchChild(get_parent(), 'reg_move', true)
				#nextMoveChild = get_parent().get_child(2)
				#print_debug(nextMoveChild)
				if nextMoveChild is Area2D:
					nextMoveChild.visible = false
					
	
	#print_debug(piece.get_name())
	if piece.variant == 'pawn':
		if get_parent().get_name().contains('spc_open'):
			if piece.didOpening == true or eat_mode:
				get_parent().visible = false
		
		if get_parent().get_name().contains('spc_eat'):
			if !eat_mode:
				get_parent().visible = false
		
		if get_parent().get_name().contains('reg_move_up'):
			if eat_mode:
				get_parent().visible = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(_delta: float) -> void:
	#pass


func _on_button_down() -> void:
	piece.didOpening = true
	
	self_modulate = Color(0,0,1)
	
	piece.grandparent.turn = 'white' if piece.grandparent.turn == 'black' else 'black'
	
	# REMEMBER TO ENABLE !!
	piece.pieceMove.visible = false
	piece.picked = false
	piece.grandparent.get_node('piece_info_icon').texture = null
	piece.grandparent.setInfoText('')
	piece.grandparent.get_node('selector').visible = false
	
	if eat_mode:
		if eat_to: eat_to.hitSeizure()
		var newHitParticle = hitParticle.instantiate()
		newHitParticle.get_node('label').text = str(-piece.damage)
		piece.grandparent.add_child(newHitParticle)
		newHitParticle.global_position = global_position
		
		for each in get_parent().get_overlapping_areas():
			if each.get_name().contains('piece'):
				each.updateHealth(-piece.damage, 'add')
				if each.health <= 0:
					if piece.color == 'black': pivot_offset = abs(pivot_offset) * -1
					piece.global_position = global_position + pivot_offset
		
		piece.get_node('sfx_eat').pitch_scale = randf_range(0.5, 1.5)
		piece.get_node('sfx_eat').play()
	
	else:
		if piece.color == 'black': pivot_offset = abs(pivot_offset) * -1
		piece.global_position = global_position + pivot_offset
		
		piece.get_node('sfx_move').pitch_scale = randf_range(0.5, 1.5)
		piece.get_node('sfx_move').play()
		
	
	await get_tree().create_timer(0.1).timeout
	if piece.variant == 'pawn':
		for ea in piece.get_overlapping_areas():
			if ea.get_name().contains('promotion_area'):
				piece.variant = 'queen'
				piece._ready()
				
				var newPromoteParticle = promoteParticle.instantiate()
				piece.add_child(newPromoteParticle)


func searchParent(node, targetMatch, searchByName = false, matchWholeWord = false):
	if (node.get_parent() == null): return 'searchParent() err: no matching target'
	if (node is not Object): return 'searchParent() err: node is not an object'
	if (targetMatch == null): return 'searchParent() err: target to match is null'
	
	match (searchByName):
		false:
			if (node.get_parent() == targetMatch): 
				#print('searchParent() found by node')
				return node.get_parent()
			return searchParent(node.get_parent(), targetMatch, searchByName)
		true:
			if matchWholeWord:
				if (node.get_parent().get_name() == targetMatch): 
					#print('searchParent() found by name')
					return node.get_parent()
			else:
				if (node.get_parent().get_name().contains(targetMatch)): 
					#print('searchParent() found by name')
					return node.get_parent()
			return searchParent(node.get_parent(), targetMatch, searchByName)

func searchChild(node, targetMatch, searchByName = false):
	if (node.get_children() == null): return 'searchChild() err: no matching target'
	if (node is not Object): return 'searchChild() err: node is not an object'
	if (targetMatch == null): return 'searchChild() err: target to match is null'
	
	#print_debug(node.get_path())
	#print_debug(node.get_children())
	for e in node.get_children():
		#print_debug(e)
		if searchByName:
			if e.get_name().contains(targetMatch):
				return e
			
		else:
			if e == targetMatch:
				return e
	
		#return searchChild(e, targetMatch, searchByName)
