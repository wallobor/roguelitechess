extends Node2D

@onready var piece = preload("res://piece.tscn")

var increment = 0

func _ready() -> void:
	for each in get_children():
		var generate_piece = piece.instantiate()
		
		if each.name.contains('pawn'): 
			generate_piece.variant = 'pawn'
		elif each.name.contains('rook'): 
			generate_piece.variant = 'rook'
		elif each.name.contains('knight'): 
			generate_piece.variant = 'knight'
		elif each.name.contains('bishop'): 
			generate_piece.variant = 'bishop'
		elif each.name.contains('king'): 
			generate_piece.variant = 'king'
		elif each.name.contains('queen'): 
			generate_piece.variant = 'queen'
		
		generate_piece.global_position = each.position
		generate_piece.name = 'piece' + str(increment)
		generate_piece.color = 'black'
		add_child(generate_piece)
		increment += 1
	return


func _process(delta: float) -> void:
	
	return
