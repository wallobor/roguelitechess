extends Node2D

@export var depth_index = 1
@export var turn = 'white'
@export var openingTotalMove = 0

func _ready() -> void:
	$piece_info_icon.texture = null
	pass


func _process(delta: float) -> void:
	if (turn == 'white'):
		setMovable(get_node("anchor_white"), 'white', true)
		setMovable(get_node("anchor_black"), 'black', false)
	else:
		setMovable(get_node("anchor_black"), 'black', true)
		setMovable(get_node("anchor_white"), 'white', false)
	pass
	
	for each in $anchor_black.get_children():
		if each.get_name().contains('piece'):
			each.get_node('depth_debug').position = each.position
			
	for each in $anchor_white.get_children():
		if each.get_name().contains('piece'):
			each.get_node('depth_debug').position = each.position
			
	$debugInfo.text = str('Mouse Global Pos: ', get_global_mouse_position(), '
						Color Turn: ', turn)


func setMovable(parentNode, color, state):
	for each in parentNode.get_children():
		if (each.name.contains('piece') and each.color == color):
			for ea in each.get_children():
				if ea.name == 'pick':
					ea.visible = state
					#print_debug(ea.get_parent().color , " " , ea.visible)
					#ea.disabled = !state


func setWin(color):
	# CHANGE SCENE HERE
	$background_music.stop()
	$gameWin.READYONIT()
	


func setInfoText(s):
	$piece_info_background/piece_info_text.text = str(s)
