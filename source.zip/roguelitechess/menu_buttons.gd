extends Area2D

@export var clickable = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("mouse_left"):
		if clickable:
			#get_parent().get_node('sfx_click').pitch_scale = randf_range(0.75, 1.25)
			get_parent().get_node('sfx_click').play()
			
			match get_name():
				'button_play':
					get_tree().change_scene_to_file("res://board.tscn")
					pass
					
				'button_info':
					pass
					
				'button_exit':
					get_tree().quit()
					pass
	pass


func _on_area_entered(area: Area2D) -> void:
	if area == get_parent().get_node("mouse_ify"):
		clickable = true
		scale = Vector2(1.3, 1.3)
		rotation_degrees = -3 if randi_range(0,1) == 0 else 3
	pass # Replace with function body.


func _on_area_exited(area: Area2D) -> void:
	if area == get_parent().get_node("mouse_ify"):
		clickable = false
		scale = Vector2(1.0, 1.0)
		rotation_degrees = 0
	pass # Replace with function body.
