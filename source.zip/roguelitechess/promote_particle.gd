extends Node2D

var rot_to = randi_range(-1,1)
var scale_rand = randf_range(0.25,1.0)

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if rot_to == 0: rot_to = 1
	scale = Vector2(scale_rand, scale_rand)
	position += Vector2(randf_range(-3,3)*10, randf_range(-3,3)*10)
	await get_tree().create_timer(1.0).timeout
	queue_free()
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	rotate(deg_to_rad(300 * delta * rot_to))
	pass
