extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _on_button_exit_area_entered(area: Area2D) -> void:
	checkAreaAndPlaySound(area)


func _on_button_info_area_entered(area: Area2D) -> void:
	checkAreaAndPlaySound(area)


func _on_button_play_area_entered(area: Area2D) -> void:
	checkAreaAndPlaySound(area)


func checkAreaAndPlaySound(a):
	if a == $mouse_ify:
		$sfx_hover.play()
